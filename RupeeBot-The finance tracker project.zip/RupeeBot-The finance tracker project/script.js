function sendMessage(){
    let userMessage=document.getElementById("userInput").value;  //Get user input
    let chatbox=document.getElementById("chatbox");  //Get chatbox container
    if(userMessage.trim()!=="")
    {
        //Check if message is not empty
        chatbox.innerHTML+=`<p><b>You: </b> ${userMessage}</p>`;  //Display user message

        //Default bot response
        let botResponse="I'm still learning. Please ask another question!";

        //Simple bot logic based on keywords
        if(userMessage.toLowerCase().includes("budget"))
        {
            botResponse="To manage your budget, try tracking your expenses daily!";
        }
        else if(userMessage.toLowerCase().includes("save money"))
        {
            botResponse="Consider setting aside at least 20% of your income for savings!";
        }

        //Display bot response with a slight delay
        setTimeout(()=>{
            chatbox.innerHTML+=`<p><b>Bot: </b> ${botResponse}</p>`;
            chatbox.scrollHeight;  //Auto-scroll to latest message
        }, 1000);

        //Clear input field after sending message

        document.getElementById("userInput").value="";
    }
}